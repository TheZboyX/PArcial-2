import static spark.Spark.*;

import java.util.HashMap;
import java.util.Map;

import freemarker.core.ReturnInstruction.Return;
import spark.ModelAndView;
import spark.template.freemarker.FreeMarkerEngine;

public class App {
    public static void main(String[] args) {
    	port(1234);
        get("/hello", (req, res) -> {
        	res.redirect("/home");
        	return null;
        });
       
        
        get("/home", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	User user = new User("Luis", "Rojas");
        	model.put("user", user);
        	model.put("title", "Alzahro");
        	return new ModelAndView(model, "home.ftl");
        }, new FreeMarkerEngine());
        
        get("/contat", (req, res) -> {
        	res.redirect("/contacto");
        	return null;
        });
        
        get("/contacto", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	model.put("title", "Alzahro");
        	
        	
        	return new ModelAndView(model, "contacto.ftl");
        }, new FreeMarkerEngine());
        
        post("/datosu", (req, res) -> {
        	
	        String nombre = req.queryParamOrDefault("nombre", "Algenis");
	        String apellido = req.queryParamOrDefault("apellido", "Rodriguez");
	        Map<String, Object> model = new HashMap<>();
	        model.put("title", "Alzahro");
	        User user = new User (nombre, apellido);
	        model.put("user", user);
        	return new ModelAndView(model, "datosu.ftl");
        	
        }, new FreeMarkerEngine()); 
      /*  get("/me", (req, res)->{
        	Map<String, Object> model = new HashMap<>();
        	User u = req.session().attribute("usuarioGuardado");
        	model.put("user", u);
        	return new ModelAndView(model, "datosu");
        });new FreeMarkerEngine();*/
    };
    }
