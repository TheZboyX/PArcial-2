import static spark.Spark.*;

import java.util.HashMap;
import java.util.Map;


import spark.ModelAndView;
import spark.template.freemarker.FreeMarkerEngine;

public class App {
    public static void main(String[] args) {
    	staticFileLocation("/public");
    	port(1234);
        get("/hello", (req, res) -> {
        	res.redirect("/home");
        	return null;
        });
       
        
        get("/home", (req , res) ->{
        	
        	Map<String, Object> model = new HashMap<>();
        	User user = new User("Algenis", "Rodriguez");
        	model.put("user", user);
        	model.put("title", "Alzahro");
        	return new ModelAndView(model, "home.ftl");
        }, new FreeMarkerEngine());
        get("/articulos", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	User user = new User("Algenis", "Rodriguez");
        	model.put("user", user);
        	model.put("title", "Alzahro");
        	return new ModelAndView(model, "articulos.ftl");
        }, new FreeMarkerEngine());
        get("/nosotros", (req , res) ->{
        	
        	Map<String, Object> model = new HashMap<>();
        	User user = new User("Algenis", "Rodriguez");
        	model.put("user", user);
        	model.put("title", "Alzahro");
        	return new ModelAndView(model, "nosotros.ftl");
        }, new FreeMarkerEngine());
       
        
        
        get("/contactanos", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	model.put("title", "Alzahro");
        	
        	
        	return new ModelAndView(model, "contactanos.ftl");
        }, new FreeMarkerEngine());
        get("/me", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	model.put("title", "Alzahro");
        	
        	
        	return new ModelAndView(model, "perfil.ftl");
        }, new FreeMarkerEngine());
        
        get("/registrarse", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	model.put("title", "Alzahro");
        	
        	
        	return new ModelAndView(model, "registro.ftl");
        }, new FreeMarkerEngine());
        get("/login", (req , res) ->{
        	Map<String, Object> model = new HashMap<>();
        	model.put("title", "Alzahro");
        	
        	
        	return new ModelAndView(model, "login.ftl");
        }, new FreeMarkerEngine());
        
        post("/datosu", (req, res) -> {
        	
	        String nombre = req.queryParamOrDefault("nombre", "Algenis");
	        String apellido = req.queryParamOrDefault("apellido", "Rodriguez");
	        Map<String, Object> model = new HashMap<>();
	        model.put("title", "Alzahro");
	        User user = new User (nombre, apellido);
	        model.put("user", user);
        	return new ModelAndView(model, "datosu.ftl");
        	
        }, new FreeMarkerEngine()); 
      /*  get("/me", (req, res)->{
        	Map<String, Object> model = new HashMap<>();
        	User u = req.session().attribute("usuarioGuardado");
        	model.put("user", u);
        	return new ModelAndView(model, "datosu");
        });new FreeMarkerEngine();*/
    };
    }
